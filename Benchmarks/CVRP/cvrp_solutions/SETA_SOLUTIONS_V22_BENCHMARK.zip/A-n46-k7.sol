Instance: A-n46-k7
BKS: 914.0
GSL_Result: 937.28
Gap: +2.55%
Runtime: 0.0103s
Route 1: 38 3 31 5 39
Route 2: 6 4 11 45 26 19 36 20
Route 3: 10 24
Route 4: 12 9 34 43 17 25 16
Route 5: 15 27 14 44 7 46 18
Route 6: 29 42 21 28 2 41 35 32 30 22
Route 7: 37 40 13 8 23 33
