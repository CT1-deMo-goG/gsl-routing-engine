Instance: A-n37-k5
BKS: 669.0
GSL_Result: 732.55
Gap: +9.50%
Runtime: 0.0078s
Route 1: 4 25 10 9 28 12 21 20 3 15 24
Route 2: 8 14 34 6 7 11 13 18
Route 3: 17 2 23 5 37 16
Route 4: 22
Route 5: 31 26 36 19 27 32 29 33 30 35
