Instance: A-n32-k5
BKS: 784.0
GSL_Result: 863.10
Gap: +10.09%
Runtime: 0.0068s
Route 1: 27 13 2 8 14 7 15
Route 2: 24 4 3 18 20 32 22
Route 3: 29 5 12 9 19 10 23 16 30
Route 4: 17 31
Route 5: 21 6 26 11 28 25
