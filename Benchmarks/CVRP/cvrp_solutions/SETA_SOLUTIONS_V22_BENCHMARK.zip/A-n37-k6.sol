Instance: A-n37-k6
BKS: 949.0
GSL_Result: 980.39
Gap: +3.31%
Runtime: 0.0070s
Route 1: 9 6 4 2 10 27 20
Route 2: 28 33 16 31 11 5
Route 3: 8 17 25 30 37
Route 4: 14 26 36
Route 5: 15 19 18 35 32 7
Route 6: 12 13 23 24 29 3 22 34 21
