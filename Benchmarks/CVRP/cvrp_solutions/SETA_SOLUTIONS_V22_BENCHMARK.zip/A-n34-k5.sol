Instance: A-n34-k5
BKS: 778.0
GSL_Result: 811.09
Gap: +4.25%
Runtime: 0.0072s
Route 1: 22 4 13 10 23 17 3 34
Route 2: 11 14 19 21 5 27
Route 3: 6 31 25 30 8 15
Route 4: 7 9 2 24 28
Route 5: 16 12 20 18 26 32 29 33
