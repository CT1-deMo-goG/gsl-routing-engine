Instance: A-n44-k6
BKS: 937.0
GSL_Result: 997.37
Gap: +6.44%
Runtime: 0.0104s
Route 1: 3 42 37 23 32 9
Route 2: 5 18 13 4 26 7
Route 3: 27 11 12 38 43 33 22 6 25 8
Route 4: 24 41 30 44 14 15 39 10
Route 5: 35 34 20 28 29 16
Route 6: 40 17 21 19 36 2 31
