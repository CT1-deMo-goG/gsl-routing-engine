Instance: A-n33-k6
BKS: 742.0
GSL_Result: 764.54
Gap: +3.04%
Runtime: 0.0069s
Route 1: 5 9 4 10 16 21 3 6
Route 2: 7 8 20 30 12 11
Route 3: 13 22
Route 4: 15 23 27 25 24 32
Route 5: 18 19 2 14
Route 6: 33 26 17 31 28 29
