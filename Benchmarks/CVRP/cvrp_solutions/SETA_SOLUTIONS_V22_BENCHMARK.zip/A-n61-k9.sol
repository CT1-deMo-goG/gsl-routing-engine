Instance: A-n61-k9
BKS: 1034.0
GSL_Result: 1091.08
Gap: +5.52%
Runtime: 0.0529s
Route 1: 4 39 60 11
Route 2: 21 7 42 54 9 50
Route 3: 10 14 51 15 24 8
Route 4: 34 43 33 44 27 5 23 13
Route 5: 17 49 36 19 57 28 22 37 30 26
Route 6: 2 12 61 32 53 58 18
Route 7: 20 25 16 31 56
Route 8: 40 29 45 35 48 59 52
Route 9: 41 3 6 55 47 46 38
