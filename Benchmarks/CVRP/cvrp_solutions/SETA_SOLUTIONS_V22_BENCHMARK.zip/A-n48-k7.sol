Instance: A-n48-k7
BKS: 1073.0
GSL_Result: 1137.06
Gap: +5.97%
Runtime: 0.0123s
Route 1: 45 7 2 6 32 13
Route 2: 8 4 21 27 40 9 28 10 30 35
Route 3: 15 18 17 48 42
Route 4: 24 44 36 19
Route 5: 22 31 47 14 25 5 12 43 16
Route 6: 23 39 26 20 38 37 33
Route 7: 41 46 29 34 11 3
