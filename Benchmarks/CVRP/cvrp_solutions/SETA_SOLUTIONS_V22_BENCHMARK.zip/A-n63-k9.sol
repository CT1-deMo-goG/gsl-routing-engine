Instance: A-n63-k9
BKS: 1616.0
GSL_Result: 1704.45
Gap: +5.47%
Runtime: 0.0237s
Route 1: 20 21 35 3 31 30 55 27
Route 2: 8 61 37 49 62 17
Route 3: 26 57 34 12
Route 4: 16 13 29 22 45
Route 5: 11 48 5 19 2 47 44 32 39
Route 6: 6 46 28 60 25 9 50 14
Route 7: 4 42 43 10 40 23
Route 8: 56 41 15 59 33 18 38 7
Route 9: 24 53 63 58 52 36 51 54
