Instance: A-n39-k5
BKS: 822.0
GSL_Result: 892.90
Gap: +8.63%
Runtime: 0.0089s
Route 1: 5 19 7 15
Route 2: 10 39 2 21 24 32 13 34 26 20
Route 3: 16 11 3 33 6 30
Route 4: 9 12 18 27 28 37 29 14 31 22
Route 5: 25 35 38 36 23 4 8 17
