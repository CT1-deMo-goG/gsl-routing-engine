Instance: A-n65-k9
BKS: 1174.0
GSL_Result: 1290.67
Gap: +9.94%
Runtime: 0.0637s
Route 1: 54 60 57 45
Route 2: 61 42 51 36 37 4 5 52
Route 3: 13 14 20 25 53 9 11 41
Route 4: 47 65 7 35 48 18
Route 5: 34 2 24 58 49 55 64 12
Route 6: 16 28 15 23 10 32 27
Route 7: 44 50 38 31 6 63
Route 8: 40 8 29 19 26 22 56 30
Route 9: 33 21 59 62 43 39 3 17 46
