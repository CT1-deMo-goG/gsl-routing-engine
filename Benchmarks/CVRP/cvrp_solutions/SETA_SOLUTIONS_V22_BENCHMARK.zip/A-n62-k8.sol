Instance: A-n62-k8
BKS: 1288.0
GSL_Result: 1362.67
Gap: +5.80%
Runtime: 0.0221s
Route 1: 46 48 43 2 10 26 32
Route 2: 8 21 41 62 30 9 11 52
Route 3: 53 38 23 45 3 47 31 19 13 54
Route 4: 12 5 22 42 24 28 40 25 4 55 14
Route 5: 17 37
Route 6: 16 39 20 49 57 29
Route 7: 51 18 59 34 36 50
Route 8: 44 7 33 58 56 27 60 35 61 6 15
