Instance: A-n36-k5
BKS: 799.0
GSL_Result: 814.89
Gap: +1.99%
Runtime: 0.0134s
Route 1: 2 23 33 14 18 31 30 34 19 22
Route 2: 11 8 27
Route 3: 10 29 35 3 36 9 16
Route 4: 15 24 5 20 32 4 7 13
Route 5: 17 12 25 28 26 6 21
