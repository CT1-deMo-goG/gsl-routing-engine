Instance: A-n63-k10
BKS: 1314.0
GSL_Result: 1349.11
Gap: +2.67%
Runtime: 0.0184s
Route 1: 46 40 2 42 10 13 3 15 41
Route 2: 39 5 27 14 29 21
Route 3: 38 9 36 28 7 30
Route 4: 50 19 6 4 43 20 11 60
Route 5: 16 57 18
Route 6: 22 47 61 55
Route 7: 34 56 23 59 52
Route 8: 25 8 62 24 17 54 26
Route 9: 63 51 58 33 35 12 48 45 32
Route 10: 53 44 31 37 49
