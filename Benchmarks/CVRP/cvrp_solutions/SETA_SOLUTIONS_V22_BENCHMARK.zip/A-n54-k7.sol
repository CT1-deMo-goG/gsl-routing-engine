Instance: A-n54-k7
BKS: 1167.0
GSL_Result: 1202.41
Gap: +3.03%
Runtime: 0.0203s
Route 1: 19 6 51 40 8 29 5 44
Route 2: 31 26 48 7 17
Route 3: 36 11 18 2 30 50 24
Route 4: 13 38 49 41 32 9 20
Route 5: 14 23 4 54 45
Route 6: 21 37 46 27 22 34 10 39 12 16
Route 7: 33 15 28 3 25 43 52 47 42 35 53
