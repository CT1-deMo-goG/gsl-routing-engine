Instance: A-n39-k6
BKS: 831.0
GSL_Result: 856.93
Gap: +3.12%
Runtime: 0.0083s
Route 1: 2 37 18 24 22 19 23 35 33
Route 2: 27 6 10 29 30 4 25
Route 3: 34 20 5 17 11 28
Route 4: 14
Route 5: 12 7 21 31 16
Route 6: 8 9 3 26 36 15 32 38 39 13
