Instance: A-n45-k6
BKS: 944.0
GSL_Result: 981.28
Gap: +3.95%
Runtime: 0.0102s
Route 1: 10 23 17 5 43 37 40 13 16
Route 2: 27 30 8 29 24 26 3 39
Route 3: 15 32 36 2 45 7
Route 4: 4 11 9 42 34 22 6 21 33
Route 5: 19 18 12 41 31 20 35
Route 6: 25 38 28 44 14
