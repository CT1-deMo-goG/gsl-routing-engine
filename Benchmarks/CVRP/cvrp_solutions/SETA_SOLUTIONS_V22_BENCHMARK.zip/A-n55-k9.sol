Instance: A-n55-k9
BKS: 1073.0
GSL_Result: 1103.61
Gap: +2.85%
Runtime: 0.0384s
Route 1: 37 38 35 4 8 5
Route 2: 51 2 46 7
Route 3: 13 11 6 54 41 17 39 33
Route 4: 14 55 24 53 25 45 49
Route 5: 15 47 21 27 32 43
Route 6: 31 23 20 28 29 42
Route 7: 9 22 19 30 26
Route 8: 34 12 16 52 3 18
Route 9: 44 36 10 50 40 48
