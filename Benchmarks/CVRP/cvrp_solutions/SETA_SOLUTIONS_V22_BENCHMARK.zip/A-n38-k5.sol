Instance: A-n38-k5
BKS: 730.0
GSL_Result: 771.07
Gap: +5.63%
Runtime: 0.0085s
Route 1: 33 21 38 32 29 10 3 15
Route 2: 8 6 12 28 23
Route 3: 19 20 35 31 11 22 25
Route 4: 27 13 4 2 5 17 26 7 30
Route 5: 16 14 37 18 36 24 34 9
