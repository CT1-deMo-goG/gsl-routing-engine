Instance: A-n64-k9
BKS: 1401.0
GSL_Result: 1478.28
Gap: +5.52%
Runtime: 0.1316s
Route 1: 63 4 54 16
Route 2: 47 48 64 3 59 55 6
Route 3: 7 21 52 20 43
Route 4: 11 42 14 62 25 53 57
Route 5: 13 44 29 2 18 28 15 31
Route 6: 39 19 23 58 12
Route 7: 26 30 49 34
Route 8: 36 27 22 8 41 37 40 45 50 51 32 60
Route 9: 46 10 35 24 38 56 5 9 17 61 33
