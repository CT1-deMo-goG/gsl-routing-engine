Instance: A-n33-k5
BKS: 661.0
GSL_Result: 717.04
Gap: +8.48%
Runtime: 0.0051s
Route 1: 3 33 14 21 5 16
Route 2: 17 4 10 18 11 13
Route 3: 31 26 28 6 27 8 9
Route 4: 7 20 15 22 2 30 32 12
Route 5: 23 24 29 19 25
