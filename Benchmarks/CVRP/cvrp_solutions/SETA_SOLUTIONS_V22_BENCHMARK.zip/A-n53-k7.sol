Instance: A-n53-k7
BKS: 1010.0
GSL_Result: 1093.28
Gap: +8.25%
Runtime: 0.0363s
Route 1: 2 52 47 9 36 32
Route 2: 48 4 34 7 21
Route 3: 5 8 17 33 16 20 24 43 44 51 37 50 30 45
Route 4: 26 40 6 15 22 18 10
Route 5: 35 14 53 25 12 42
Route 6: 28 39 19 41 27 11
Route 7: 29 23 13 49 46 3 38 31
