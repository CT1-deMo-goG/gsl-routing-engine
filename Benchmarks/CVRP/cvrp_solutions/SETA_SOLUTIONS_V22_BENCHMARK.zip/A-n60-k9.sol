Instance: A-n60-k9
BKS: 1354.0
GSL_Result: 1407.09
Gap: +3.92%
Runtime: 0.0184s
Route 1: 26 4 21 17 42
Route 2: 36 40 9 14 8 20
Route 3: 19 34 39 60 53 48 15
Route 4: 43 46 6 55 11
Route 5: 47 41 12 5 22 7 35 24
Route 6: 51 44 57 13 52 10 33
Route 7: 3 2 49 23 37 31 50
Route 8: 30 38 58 28 18 27 16 56
Route 9: 59 25 45 54 32 29
