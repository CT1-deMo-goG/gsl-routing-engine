Instance: A-n45-k7
BKS: 1146.0
GSL_Result: 1190.57
Gap: +3.89%
Runtime: 0.0441s
Route 1: 3 5 7 29 25 15 10 22
Route 2: 4 12 28 34 45
Route 3: 41 21 17 8 19 33
Route 4: 23 6 31 38 2 43 9
Route 5: 13 27 35 40 36
Route 6: 14 39 18 24 26 16 11
Route 7: 32 20 37 30 42 44
