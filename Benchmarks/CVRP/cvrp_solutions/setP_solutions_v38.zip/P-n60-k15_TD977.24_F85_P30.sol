Route #1: 13 54 19 35 8
Route #2: 12 40 17
Route #3: 52 27 29 45
Route #4: 58 10 31
Route #5: 32 9 39
Route #6: 25 55 18 50 44
Route #7: 1 43 41 42 22
Route #8: 3 24 49 56 23
Route #9: 4 34 46
Route #10: 7 11 38
Route #11: 2 28 30
Route #12: 51 16 33 6
Route #13: 14 59 53
Route #14: 57 15 20 37 5
Route #15: 21 36 47 48
Route #16: 26
Cost 977.24
