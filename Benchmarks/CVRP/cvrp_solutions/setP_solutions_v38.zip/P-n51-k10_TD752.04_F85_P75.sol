Route #1: 18 4 47
Route #2: 16 50 21 29 2
Route #3: 24 43 7 23 48
Route #4: 10 39 30 34 9 46
Route #5: 3 36 35 20 32
Route #6: 27 6 14 25
Route #7: 8 26 31 28 22 1
Route #8: 5 49 38 11
Route #9: 42 19 40 41 13
Route #10: 17 44 45 33 15 37
Route #11: 12
Cost 752.04
