Route #1: 4
Route #2: 3 10
Route #3: 8
Route #4: 7 9 13
Route #5: 2
Route #6: 5 14
Route #7: 6
Route #8: 12 15 11
Route #9: 1
Cost 473.78
