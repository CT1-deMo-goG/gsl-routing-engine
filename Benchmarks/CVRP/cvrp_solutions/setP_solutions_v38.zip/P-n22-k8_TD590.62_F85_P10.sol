Route #1: 16
Route #2: 11 13
Route #3: 19
Route #4: 8 6 1 2 9
Route #5: 10 3 4
Route #6: 14 20 21
Route #7: 15 18 17
Route #8: 5 7
Route #9: 12
Cost 590.62
