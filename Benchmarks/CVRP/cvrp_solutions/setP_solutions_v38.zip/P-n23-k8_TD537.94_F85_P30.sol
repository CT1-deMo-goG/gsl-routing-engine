Route #1: 4 11
Route #2: 2
Route #3: 6
Route #4: 5 14 22
Route #5: 18 19 3
Route #6: 7 20 21
Route #7: 1 10 12 15
Route #8: 8 16
Route #9: 13 9 17
Cost 537.94
