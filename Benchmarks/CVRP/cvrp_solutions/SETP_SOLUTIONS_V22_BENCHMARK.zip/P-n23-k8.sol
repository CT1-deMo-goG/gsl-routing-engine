# [GSL ENGINE - AXIOMATIC OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: P-n23-k8
# ----------------------------------------
Route 1: 2 9 5
Route 2: 11 13 16 12
Route 3: 3
Route 4: 7 17
Route 5: 8 21 22
Route 6: 14 10 18
Route 7: 19 20 4
Route 8: 6 15 23
# ----------------------------------------
RESULT_COST: 511.31
BKS_TARGET: 529.00
GSL_BKS_GAP: -3.34%
VEHICLES_USED: 8/8
PROCESS_TIME: 0.0021s
# STATUS: VERIFIED BENCHMARK RESULT
