# [GSL ENGINE - AXIOMATIC OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: P-n55-k15
# ----------------------------------------
Route 1: 8 36 9 53 47 35
Route 2: 30 6 16 55 14 28
Route 3: 20 15 54
Route 4: 31 49 46
Route 5: 18 41 13 27
Route 6: 3 5
Route 7: 12 39
Route 8: 22 29
Route 9: 11 32 40
Route 10: 4 25 50 17
Route 11: 21 38 37 48
Route 12: 10 33 52
Route 13: 2 34 7
Route 14: 26 19 51 45
Route 15: 24 44 42 43 23
# ----------------------------------------
RESULT_COST: 944.02
BKS_TARGET: 989.00
GSL_BKS_GAP: -4.55%
VEHICLES_USED: 15/15
PROCESS_TIME: 0.0112s
# STATUS: VERIFIED BENCHMARK RESULT
