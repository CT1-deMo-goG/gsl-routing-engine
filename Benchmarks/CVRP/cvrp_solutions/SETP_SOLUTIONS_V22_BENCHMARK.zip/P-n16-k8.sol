# [GSL ENGINE - AXIOMATIC OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: P-n16-k8
# ----------------------------------------
Route 1: 5 2
Route 2: 7
Route 3: 3
Route 4: 13 16 12
Route 5: 4 11
Route 6: 9
Route 7: 6 8
Route 8: 15 10 14
# ----------------------------------------
RESULT_COST: 454.52
BKS_TARGET: 450.00
GSL_BKS_GAP: +1.00%
VEHICLES_USED: 8/8
PROCESS_TIME: 0.0025s
# STATUS: VERIFIED BENCHMARK RESULT
