# [GSL ENGINE - AXIOMATIC OPTIMIZATION]
# MODULE: GSL_CVRP_V22 (BENCHMARK)
# INSTANCE: P-n22-k8
# ----------------------------------------
Route 1: 18 19 16 13
Route 2: 15 21 22
Route 3: 11 4 5
Route 4: 17
Route 5: 9 7 2 3 10
Route 6: 6 8
Route 7: 12 14
Route 8: 20
# ----------------------------------------
RESULT_COST: 571.23
BKS_TARGET: 603.00
GSL_BKS_GAP: -5.27%
VEHICLES_USED: 8/8
PROCESS_TIME: 0.0019s
# STATUS: VERIFIED BENCHMARK RESULT
